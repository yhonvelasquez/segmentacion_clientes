//Mostrar mensaje

import streamlit as st

def main():
    st.title("Hola Streamlit")

# Llama a la función main sin la condición de __name__
main()